package io.flutter.plugins.videoplayer;

class VideoPlayerOptions {
  public boolean mixWithOthers;
}
